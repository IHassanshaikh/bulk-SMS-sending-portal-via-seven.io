import express from "express";
import multer from "multer";
import { parse } from "csv-parse";
import fs from "fs";
import * as XLSX from "xlsx";
import { validatePhone } from "../utils/validator.js";
import Contact from "../models/Contact.js";
import CampaignList from "../models/CampaignList.js";

const router = express.Router();
const upload = multer({ dest: "uploads/" });



router.post("/upload", upload.single("file"), async (req, res) => {
    console.log("Upload request received");
    console.log("req.file:", req.file);
    console.log("req.body:", req.body);
    const contacts = [];
    let campaignId = null;

    if (!req.file) {
        console.error("No file in request");
        return res.status(400).json({ success: false, message: "No file uploaded" });
    }

    console.log("Processing file:", req.file.originalname, "Mimetype:", req.file.mimetype, "Path:", req.file.path);

    try {
        if (req.body.campaignName) {
            const campaign = await new CampaignList({ name: req.body.campaignName }).save();
            campaignId = campaign._id;
        }

        const handleContacts = async (parsedContacts) => {
            console.log(`Parsed ${parsedContacts.length} contacts`);
            try {
                await Contact.insertMany(parsedContacts, { ordered: false });
                if (fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
                console.log("Insertion successful");
                res.json({ success: true, total: parsedContacts.length, campaignId });
            } catch (error) {
                console.error("Insertion error:", error.message);
                if (error.code === 11000 || error.writeErrors) {
                    // Some duplicates found
                    const insertedCount = error.insertedDocs ? error.insertedDocs.length : (parsedContacts.length - error.writeErrors.length);
                    res.json({
                        success: true,
                        total: insertedCount,
                        message: `Uploaded ${insertedCount} contacts. Skipped ${parsedContacts.length - insertedCount} duplicates.`,
                        campaignId
                    });
                    if (fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
                } else {
                    res.status(500).json({ success: false, message: error.message });
                }
            }
        };

        // ROBUST PARSING STRATEGY
        // 1. Read file as buffer (bypasses extension check issues)
        // 2. Let XLSX library detect format (works for CSV, Text, XLS, XLSX)
        const fileBuffer = fs.readFileSync(req.file.path);
        const workbook = XLSX.read(fileBuffer, { type: "buffer" });

        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];

        // Convert to JSON
        const jsonData = XLSX.utils.sheet_to_json(sheet);

        const processedContacts = [];
        jsonData.forEach(row => {
            const normalizedRow = {};
            // Normalize keys
            Object.keys(row).forEach(key => {
                normalizedRow[key.trim().toLowerCase()] = row[key];
            });

            console.log("Row Keys:", Object.keys(normalizedRow)); // DEBUG LOG

            let phone = normalizedRow.phone || normalizedRow.phones || normalizedRow.number || normalizedRow.numbers || normalizedRow.mobile || normalizedRow.mobiles || normalizedRow.contact || normalizedRow.contacts;

            // Data Cleaning: Scientific Notation & Numeric Handling
            if (phone) {
                if (typeof phone === 'number') {
                    // Convert number to string (e.g. 447123456789 -> "447123456789")
                    phone = String(phone);
                }

                // Remove scientific notation artifacts if present string (very rare if numeric conversion matched)
                // But cleaning all non-numeric characters except + is good practice
                // VALIDATION & FORMATTING (E.164)
                const formattedPhone = validatePhone(phone);

                if (formattedPhone) {
                    // Simplified Name Detection (User Request)
                    // Just look for 'name' or 'names'
                    let name = normalizedRow.name || normalizedRow.names || normalizedRow['full name'] || "Unknown";

                    const contact = {
                        name: name,
                        phone: formattedPhone,
                    };
                    if (campaignId) contact.campaignId = campaignId;
                    processedContacts.push(contact);
                } else {
                    // console.warn("Skipping invalid phone:", phone);
                }
            }
        });

        if (processedContacts.length === 0) {
            console.warn("No contacts found after parsing. Trying raw CSV fallback just in case.");
            return res.status(400).json({ success: false, message: "No valid contacts found in file. Please check format." });
        }

        console.log(`Parsed ${processedContacts.length} contacts`);

        // COMPLIANCE CHECK: REMOVE BLACKLISTED NUMBERS
        // Dynamically import Blacklist
        const Blacklist = (await import("../models/Blacklist.js")).default;
        const blacklistedDocs = await Blacklist.find({ phone: { $in: processedContacts.map(c => c.phone) } });
        const blacklistedPhones = new Set(blacklistedDocs.map(b => b.phone));

        const cleanContacts = processedContacts.filter(c => !blacklistedPhones.has(c.phone));
        const blockedCount = processedContacts.length - cleanContacts.length;

        if (blockedCount > 0) {
            console.log(`Compliance: Blocked ${blockedCount} contacts found in Blacklist.`);
        }

        if (cleanContacts.length === 0) {
            return res.json({
                success: true,
                total: 0,
                message: `All ${processedContacts.length} contacts were blocked by the Blacklist.`
            });
        }

        await handleContacts(cleanContacts, res); // Pass res to handle response
        if (fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);

    } catch (error) {
        console.error("Upload Error:", error);
        res.status(500).json({ error: "Failed to process file" });
    }
});

const handleContacts = async (contacts, res) => {
    try {
        // Use BulkWrite for Upsert (Update if exists, Insert if new)
        const operations = contacts.map(contact => ({
            updateOne: {
                filter: { phone: contact.phone },
                update: { $set: contact },
                upsert: true
            }
        }));

        const result = await Contact.bulkWrite(operations);

        console.log("BulkWrite Result:", result);

        const inserted = result.upsertedCount + result.insertedCount;
        const updated = result.modifiedCount;

        res.json({
            success: true,
            total: contacts.length,
            inserted: inserted,
            updated: updated,
            message: `Processed ${contacts.length} contacts. (New/Upserted: ${inserted}, Updated: ${updated})`
        });
    } catch (error) {
        console.error("BulkWrite Error:", error);
        res.status(500).json({ error: "Failed to save contacts" });
    }
};

// Get all campaign lists
router.get("/lists", async (req, res) => {
    try {
        const lists = await CampaignList.find().sort({ date: -1 });
        res.json(lists);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Get all contacts
router.get("/", async (req, res) => {
    try {
        const contacts = await Contact.find();
        res.json(contacts);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Delete a contact
router.delete("/:id", async (req, res) => {
    try {
        await Contact.findByIdAndDelete(req.params.id);
        res.json({ success: true, message: "Contact deleted" });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Bulk delete contacts
router.post("/delete-batch", async (req, res) => {
    const { ids } = req.body;
    if (!ids || !Array.isArray(ids) || ids.length === 0) {
        return res.status(400).json({ message: "No IDs provided" });
    }

    try {
        await Contact.deleteMany({ _id: { $in: ids } });
        res.json({ success: true, message: "Contacts deleted" });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

export default router;
