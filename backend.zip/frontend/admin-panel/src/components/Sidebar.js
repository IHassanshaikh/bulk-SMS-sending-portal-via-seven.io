import { Link, useLocation } from "react-router-dom";
import { useState, useEffect } from "react";
import axios from "axios";
import { API } from "../api";

export default function Sidebar() {
    const location = useLocation();
    const [balance, setBalance] = useState(null);

    const isActive = (path) => location.pathname === path;

    useEffect(() => {
        axios.get(`${API}/sms/balance`)
            .then(res => setBalance(res.data.balance.amount))
            .catch(err => console.error("Balance Fetch Error:", err));
    }, []);

    const linkStyle = (path) => ({
        display: "block",
        padding: "12px 16px",
        margin: "8px 0",
        borderRadius: "8px",
        color: isActive(path) ? "var(--accent-primary)" : "var(--text-secondary)",
        background: isActive(path) ? "var(--glass-highlight)" : "transparent",
        textDecoration: "none",
        fontWeight: isActive(path) ? "600" : "400",
        borderLeft: isActive(path) ? "3px solid var(--accent-primary)" : "3px solid transparent",
        transition: "all 0.2s ease"
    });

    return (
        <div className="glass-panel" style={{
            width: "240px",
            minHeight: "calc(100vh - 40px)",
            position: "fixed",
            top: "20px",
            left: "20px",
            padding: "20px",
            display: "flex",
            flexDirection: "column"
        }}>
            <h2 style={{
                margin: "0 0 2rem 0",
                color: "var(--text-primary)",
                fontSize: "1.25rem",
                fontWeight: "700",
                letterSpacing: "-0.025em"
            }}>SMS Panel</h2>

            <nav style={{ flex: 1 }}>
                <Link to="/" style={linkStyle("/")}>Dashboard</Link>
                <Link to="/contacts" style={linkStyle("/contacts")}>Contacts</Link>
                <Link to="/upload" style={linkStyle("/upload")}>Upload CSV</Link>
                <Link to="/sms" style={linkStyle("/sms")}>Send SMS</Link>
                <Link to="/test-sms" style={linkStyle("/test-sms")}>Test SMS</Link>
                <Link to="/logs" style={linkStyle("/logs")}>Logs</Link>
                <div style={{ height: "1px", background: "rgba(255,255,255,0.1)", margin: "10px 0" }}></div>
                <Link to="/settings" style={linkStyle("/settings")}>Settings</Link>
            </nav>

            <div style={{ padding: "15px", background: "var(--glass-highlight)", borderRadius: "8px", marginBottom: "10px" }}>
                <div style={{ fontSize: "0.85rem", color: "var(--text-secondary)", marginBottom: "5px" }}>Credits</div>
                <div style={{ fontSize: "1.2rem", fontWeight: "600", color: "var(--accent-primary)" }}>
                    {balance !== null ? `€${balance}` : "Loading..."}
                </div>
            </div>

            <button
                onClick={() => {
                    localStorage.removeItem("token");
                    window.location.href = "/login";
                }}
                style={{
                    width: "100%",
                    padding: "10px",
                    background: "rgba(239, 68, 68, 0.1)",
                    color: "#ef4444",
                    border: "1px solid rgba(239, 68, 68, 0.2)",
                    borderRadius: "8px",
                    cursor: "pointer",
                    fontSize: "0.9rem",
                    transition: "all 0.2s"
                }}
                onMouseOver={(e) => e.target.style.background = "rgba(239, 68, 68, 0.2)"}
                onMouseOut={(e) => e.target.style.background = "rgba(239, 68, 68, 0.1)"}
            >
                Sign Out
            </button>

            <div style={{ fontSize: "0.8rem", color: "var(--text-secondary)", textAlign: "center" }}>
                v1.0.0
            </div>
        </div>
    );
}
