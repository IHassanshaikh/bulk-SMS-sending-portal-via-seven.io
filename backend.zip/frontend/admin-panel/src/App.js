import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Dashboard from "./pages/Dashboard";
import Contacts from "./pages/Contacts";
import UploadCSV from "./pages/UploadCSV";
import SendSMS from "./pages/SendSMS";
import Logs from "./pages/Logs";
import Sidebar from "./components/Sidebar";

import CreateCampaign from "./pages/CreateCampaign";
import TestSMS from "./pages/TestSMS";
import LoginPage from "./pages/LoginPage";
import Settings from "./pages/Settings";
import ForgotPassword from "./pages/ForgotPassword";
import ResetPassword from "./pages/ResetPassword";

const PrivateRoute = ({ children }) => {
  const token = localStorage.getItem("token");
  return token ? children : <Navigate to="/login" />;
};

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password/:token" element={<ResetPassword />} />

        <Route path="*" element={
          <div style={{ display: "flex", minHeight: "100vh" }}>
            <Sidebar />
            <div style={{ marginLeft: "280px", flex: 1, padding: "20px" }}>
              <PrivateRoute>
                <Routes>
                  <Route path="/" element={<Dashboard />} />
                  <Route path="/contacts" element={<Contacts />} />
                  <Route path="/upload" element={<UploadCSV />} />
                  <Route path="/create-campaign" element={<CreateCampaign />} />
                  <Route path="/sms" element={<SendSMS />} />
                  <Route path="/test-sms" element={<TestSMS />} />
                  <Route path="/logs" element={<Logs />} />
                  <Route path="/settings" element={<Settings />} />
                </Routes>
              </PrivateRoute>
            </div>
          </div>
        } />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
