import { useState, useEffect } from "react";
import axios from "axios";
import { API } from "../api";

export default function SendSMS() {
    const [message, setMessage] = useState("");
    const [campaigns, setCampaigns] = useState([]);
    const [selectedCampaign, setSelectedCampaign] = useState("");
    const [loading, setLoading] = useState(false);
    const [status, setStatus] = useState("");

    // New State for Scheduling
    const [scheduleTime, setScheduleTime] = useState(""); // ISO String for input type="datetime-local"
    const [interval, setInterval] = useState(""); // Minutes

    useEffect(() => {
        // Fetch campaigns
        axios.get(`${API}/contacts/lists`)
            .then(res => setCampaigns(res.data))
            .catch(err => console.error("Failed to fetch campaigns", err));
    }, []);

    const handleSend = async () => {
        // Validation
        if (interval && interval < 1) {
            alert("Interval must be at least 1 minute.");
            return;
        }

        setLoading(true);
        setStatus("Scheduling...");
        try {
            const res = await axios.post(`${API}/sms/bulk`, {
                message,
                campaignId: selectedCampaign || null,
                interval: parseInt(interval) || 0,
                startTime: scheduleTime || null
            });
            setStatus(`Success! Status: ${res.data.message}`);
            setMessage(""); // Clear message after success
            setScheduleTime("");
            setInterval("");
        } catch (error) {
            setStatus(`Failed: ${error.response?.data?.message || "Error sending"}`);
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="page-container">
            <h1 style={{ marginBottom: "30px" }}>Create Campaign</h1>

            <div className="glass-panel" style={{ padding: "40px", maxWidth: "800px" }}>

                {/* 1. Recipient Selection */}
                <div style={{ marginBottom: "30px" }}>
                    <h3 style={{ marginBottom: "15px", color: "var(--accent-primary)", fontSize: "1.1rem" }}>1. Recipients</h3>
                    <label style={{ display: "block", marginBottom: "8px", color: "var(--text-secondary)" }}>Select Contact List</label>
                    <select
                        value={selectedCampaign}
                        onChange={(e) => setSelectedCampaign(e.target.value)}
                        className="glass-input"
                        style={{ width: "100%" }}
                    >
                        <option value="" style={{ color: "black" }}>All Contacts (Default)</option>
                        {campaigns.map(c => (
                            <option key={c._id} value={c._id} style={{ color: "black" }}>{c.name} ({c.count || "?"} contacts)</option>
                        ))}
                    </select>
                </div>

                {/* 2. Message Content */}
                <div style={{ marginBottom: "30px" }}>
                    <h3 style={{ marginBottom: "15px", color: "var(--accent-primary)", fontSize: "1.1rem" }}>2. Message</h3>
                    <label style={{ display: "block", marginBottom: "8px", color: "var(--text-secondary)" }}>SMS Content</label>
                    <textarea
                        rows="6"
                        placeholder="Type your message here..."
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        className="glass-input"
                        style={{ width: "100%", lineHeight: "1.5" }}
                    />
                    <div style={{ textAlign: "right", fontSize: "0.8rem", color: "var(--text-secondary)", marginTop: "5px" }}>
                        {message.length} characters • {Math.ceil(message.length / 160)} SMS segment(s)
                    </div>
                </div>

                {/* 3. Scheduling */}
                <div style={{ marginBottom: "40px" }}>
                    <h3 style={{ marginBottom: "15px", color: "var(--accent-primary)", fontSize: "1.1rem" }}>3. Schedule (Optional)</h3>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px" }}>
                        <div>
                            <label style={{ display: "block", marginBottom: "8px", color: "var(--text-secondary)" }}>Start Time</label>
                            <input
                                type="datetime-local"
                                value={scheduleTime}
                                onChange={(e) => setScheduleTime(e.target.value)}
                                className="glass-input"
                                style={{ width: "100%" }}
                            />
                        </div>
                        <div>
                            <label style={{ display: "block", marginBottom: "8px", color: "var(--text-secondary)" }}>Interval (Minutes)</label>
                            <input
                                type="number"
                                placeholder="0 = Instant"
                                min="0"
                                value={interval}
                                onChange={(e) => setInterval(e.target.value)}
                                className="glass-input"
                                style={{ width: "100%" }}
                            />
                            <div style={{ fontSize: "0.75rem", color: "var(--text-secondary)", marginTop: "4px" }}>
                                Delay between each message
                            </div>
                        </div>
                    </div>
                </div>

                {/* Action Buttons */}
                <div style={{ display: "flex", justifyContent: "flex-end", alignItems: "center", gap: "20px", borderTop: "1px solid rgba(255,255,255,0.1)", paddingTop: "20px" }}>
                    {status && (
                        <span style={{
                            color: status.includes("Success") ? "var(--success)" : "#ef4444",
                            fontWeight: "500"
                        }}>
                            {status}
                        </span>
                    )}

                    <button
                        className="btn-primary"
                        onClick={handleSend}
                        disabled={loading || !message}
                        style={{
                            padding: "12px 30px",
                            fontSize: "1rem",
                            background: loading ? "var(--text-secondary)" : "var(--accent-primary)"
                        }}
                    >
                        {loading ? "Processing..." : (scheduleTime || interval ? "📅 Schedule Campaign" : "🚀 Send Now")}
                    </button>
                </div>
            </div>
        </div>
    );
}
